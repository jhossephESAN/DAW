export const products = [
  {
    name: 'Phone XL',
    price: 799,
    description: 'Un buen teléfono con una de las más grandes pantallas.'
  },
  {
    name: 'Phone Mini',
    price: 699,
    description: 'Un excelente teléfono con una de las mejores cámaras.'
  },
  {
    name: 'Phone Standard',
    price: 299,
    description: 'Perfecto para el día a día.'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/